// Select all the navbar items
document.addEventListener('DOMContentLoaded', () => {
    const sections = document.querySelectorAll('section');
    const navbarList = document.getElementById('navbar__list');

    // build movment list
    sections.forEach((section) => {
        const listItem = document.createElement('li');
        const link = document.createElement('a');
        link.setAttribute('href', `#${section.id}`);
        link.textContent = section.getAttribute('data-nav');
        listItem.appendChild(link);
        navbarList.appendChild(listItem);


        // Add action for link to select the section we choose 
        link.addEventListener('click', (event) => {
            event.preventDefault();
            section.scrollIntoView({ behavior: 'smooth' });


            function changeColor(link, color) {
                // Change the background color of the link element to the color
                link.style.backgroundColor = color;
                link.onclick = changeColor(this, 'yellow');
            }

        });
    });
    // Function to check if an element is in the viewport
    window.addEventListener('scroll', () => {
        let selectedSection = null;

        sections.forEach((section) => {
            const sectionRect = section.getBoundingClientRect();
            if (sectionRect.top <= 150 && sectionRect.bottom >= 150) {
                selectedSection = section;
            }
        });

        // add responsive navigation bar with highlite background navitem 
        sections.forEach((section) => {
            if (section === selectedSection) {
                section.classList.add('your-active-class');
                navbarList.classList.add('your-active-class');
            } else {
                section.classList.remove('your-active-class');
                navbarList.classList.remove('your-active-class');
            }
        });
    });
});



// Add scroll event listener to the window
window.addEventListener('scroll', handleScroll);